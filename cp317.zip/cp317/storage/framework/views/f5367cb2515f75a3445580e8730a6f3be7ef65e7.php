<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
              <div class="card card-default">
                  <div class="card-header"><?php echo e(__('Profile Information')); ?></div>

                  <div class="card-body">
                      <form method="post" action="/profile/update/">
                          <?php echo csrf_field(); ?>

                          <?php if(session()->has('message')): ?>
                              <!-- Success Message -->
                              <div class="alert alert-success alert-dismissible fade show" role="alert">
                                  <span class="alert-icon"><i class="ni ni-like-2"></i></span>
                                  <span class="alert-text" style="color: black"><strong>Success!</strong> Your contact info has been updated!</span>
                                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                      <span aria-hidden="true">&times;</span>
                                  </button>
                              </div>
                          <?php endif; ?>

                          <!-- Name -->
                          <div class="form-group row">
                              <label class="col-md-4 col-form-label text-md-right"><font color="red">*</font><?php echo e(__('Name')); ?></label>

                              <div class="col-md-6">
                                  <input style="color: black" type="text" class="form-control" name="name" value="<?=$user->name?>" required>
                              </div>
                          </div>

                          <!-- E-Mail Address -->
                          <div class="form-group row">
                              <label class="col-md-4 col-form-label text-md-right"><font color="red">*</font><?php echo e(__('E-Mail Address')); ?></label>

                              <div class="col-md-6">
                                  <input style="color: black" type="email" class="form-control" name="email" value="<?=$user->email?>" required>
                              </div>
                          </div>

                          <!-- Username -->
                          <div class="form-group row">
                              <label class="col-md-4 col-form-label text-md-right"><font color="red">*</font><?php echo e(__('Username')); ?></label>

                              <div class="col-md-6">
                                  <input style="color: black" type="text" class="form-control" name="uname" value="<?=$user->uname?>" required>
                              </div>
                          </div>

                          <!-- Phone Number -->
                          <div class="form-group row">
                              <label class="col-md-4 col-form-label text-md-right" for="phone"><?php echo e(__('Phone Number')); ?></label>

                              <div class="col-md-6">
                                  <input style="color: black" type="text" class="form-control" name="phone" placeholder="Phone Number" value="<?php echo e($user->phone); ?>">

                                  <small>Format: 1234567890</small>
                              </div>
                          </div>

                          <p>
                              <!-- Update Button -->
                              <div class="form-group row mb-0">
                                  <div class="col-md-6 offset-md-4">
                                      <button type="submit" class="btn btn-primary">
                                              <!-- @click.prevent="update"
                                              :disabled="form.busy"> -->

                                          <?php echo e(__('Update')); ?>

                                      </button>
                                  </div>
                              </div>
                          </p>

                          <p>
                              <!-- Cancel Button -->
                              <div class="form-group row mb-0">
                                  <div class="col-md-6 offset-md-4">
                                      <button type="button" class="btn" style="background-color: #a80000; font-family: 'Nunito', 'sans-serif'">
                                          <a href="/profile" style="color: white; font-family: 'Nunito', 'sans-serif'"><?php echo e(__('Cancel')); ?></a>
                                      </button>
                                  </div>
                              </div>
                          </p>

                          <p>
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                          </p>
                      </form>
                  </div>
              </div>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/lightspeed/PhP_Examples/cp317/resources/views/profile.blade.php ENDPATH**/ ?>