<div class="card">
    <div class="card-header">Profile Details</div>

    <div class="card-body">
        <form method="post" action="/profile/details/update">
            <?php echo csrf_field(); ?>
            <!-- Phone Number -->
            <div class="form-group row">
                <label class="col-md-4 col-form-label text-md-right" for="phone"><?php echo e(__('Phone Number')); ?></label>

                <div class="col-md-6">
                    <input type="text" class="form-control" name="phone" placeholder="Phone Number">

                    <small>Format: 123-456-7890</small>
                </div>
            </div>

            <!-- Address -->
            <div class="form-group row">
                <label class="col-md-4 col-form-label text-md-right"><?php echo e(__('Address')); ?></label>

                <div class="col-md-6">
                    <input type="text" class="form-control" name="address" placeholder="Address">
                </div>
            </div>

            <!-- Update Button -->
            <div class="form-group">
                <div class="col-md-6 offset-md-4">
                    <button class="btn btn-primary">

                        Update
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php /**PATH /Users/lightspeed/PhP_Examples/cp317/resources/views/profile/update-profile-details.blade.php ENDPATH**/ ?>