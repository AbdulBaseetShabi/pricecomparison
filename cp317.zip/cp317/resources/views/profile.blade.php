@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
              <div class="card card-default">
                  <div class="card-header">{{__('Profile Information')}}</div>

                  <div class="card-body">
                      <form method="post" action="/profile/update/">
                          @csrf

                          @if(session()->has('message'))
                              <!-- Success Message -->
                              <div class="alert alert-success alert-dismissible fade show" role="alert">
                                  <span class="alert-icon"><i class="ni ni-like-2"></i></span>
                                  <span class="alert-text" style="color: black"><strong>Success!</strong> Your contact info has been updated!</span>
                                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                      <span aria-hidden="true">&times;</span>
                                  </button>
                              </div>
                          @endif

                          <!-- Name -->
                          <div class="form-group row">
                              <label class="col-md-4 col-form-label text-md-right"><font color="red">*</font>{{__('Name')}}</label>

                              <div class="col-md-6">
                                  <input style="color: black" type="text" class="form-control" name="name" value="<?=$user->name?>" required>
                              </div>
                          </div>

                          <!-- E-Mail Address -->
                          <div class="form-group row">
                              <label class="col-md-4 col-form-label text-md-right"><font color="red">*</font>{{__('E-Mail Address')}}</label>

                              <div class="col-md-6">
                                  <input style="color: black" type="email" class="form-control" name="email" value="<?=$user->email?>" required>
                              </div>
                          </div>

                          <!-- Username -->
                          <div class="form-group row">
                              <label class="col-md-4 col-form-label text-md-right"><font color="red">*</font>{{__('Username')}}</label>

                              <div class="col-md-6">
                                  <input style="color: black" type="text" class="form-control" name="uname" value="<?=$user->uname?>" required>
                              </div>
                          </div>

                          <!-- Phone Number -->
                          <div class="form-group row">
                              <label class="col-md-4 col-form-label text-md-right" for="phone">{{__('Phone Number')}}</label>

                              <div class="col-md-6">
                                  <input style="color: black" type="text" class="form-control" name="phone" placeholder="Phone Number" value="{{ $user->phone }}">

                                  <small>Format: 1234567890</small>
                              </div>
                          </div>

                          <p>
                              <!-- Update Button -->
                              <div class="form-group row mb-0">
                                  <div class="col-md-6 offset-md-4">
                                      <button type="submit" class="btn btn-primary">
                                              <!-- @click.prevent="update"
                                              :disabled="form.busy"> -->

                                          {{__('Update')}}
                                      </button>
                                  </div>
                              </div>
                          </p>

                          <p>
                              <!-- Cancel Button -->
                              <div class="form-group row mb-0">
                                  <div class="col-md-6 offset-md-4">
                                      <button type="button" class="btn" style="background-color: #a80000; font-family: 'Nunito', 'sans-serif'">
                                          <a href="/profile" style="color: white; font-family: 'Nunito', 'sans-serif'">{{__('Cancel')}}</a>
                                      </button>
                                  </div>
                              </div>
                          </p>

                          <p>
                            @if ($errors->any())
                                <div class="alert alert-danger">
                                    <ul>
                                        @foreach ($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                </div>
                            @endif
                          </p>
                      </form>
                  </div>
              </div>

            </div>
        </div>
    </div>
</div>
@endsection
